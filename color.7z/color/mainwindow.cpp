#include "mainwindow.h"

#include <QColor>
#include <QTableWidgetItem>
#include <map>
#include <string>
#include <unordered_map>

#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);
  std::map<std::string, Qt::GlobalColor> color_map{
      {"黑色", Qt::black},        {"白色", Qt::white},
      {"暗灰", Qt::darkGray},     {"灰色", Qt::gray},
      {"亮灰色", Qt::lightGray},  {"红色", Qt::red},
      {"绿色", Qt::green},        {"蓝色", Qt::blue},
      {"青色", Qt::cyan},         {"洋红色", Qt::magenta},
      {"黄色", Qt::yellow},       {"暗红色", Qt::darkRed},
      {"暗绿色", Qt::darkGreen},  {"暗蓝色", Qt::darkBlue},
      {"暗青色", Qt::darkCyan},   {"暗洋红色", Qt::darkMagenta},
      {"暗黄色", Qt::darkYellow}, {"透明", Qt::transparent},
  };

  ui->tableView->clear();
  ui->tableView->setRowCount(static_cast<int>(color_map.size()));
  ui->tableView->setColumnCount(2);
  /// ui->tableWidget->setSortingEnabled(true);
  /// ui->tableWidget->horizontalHeader()->setSectionResizeMode(
  ///     QHeaderView::Stretch);
  /// ui->tableWidget->setWindowTitle("QTableWidget & Item");
  /// ui->tableWidget->resize(400, 300);  //设置表格
  QStringList header;
  header << "color"
         << "颜色";

  ui->tableView->setHorizontalHeaderLabels(header);
  int i = 0;
  for (auto it : color_map) {
    auto color = it.second;
    auto str = it.first;
    auto item_0 = new QTableWidgetItem();
    item_0->setBackgroundColor(color);
    ui->tableView->setItem(i, 0, item_0);
    ui->tableView->setItem(i, 1, new QTableWidgetItem(QString(str.c_str())));

    i++;
  }

  ui->tableWidget->clear();
  auto num = static_cast<int>(color_map.size());
  ui->tableWidget->setRowCount(num * num);
  ui->tableWidget->setColumnCount(3);
  QStringList fix_header;
  fix_header << "color"
             << "前景色"
             << "背景色";
  ui->tableWidget->setHorizontalHeaderLabels(fix_header);
  int x = 0;
  for (auto& it1 : color_map) {
    int y = 0;
    for (auto& it2 : color_map) {
      auto color =
          new QTableWidgetItem(QString((it1.first + ", " + it2.first).c_str()));
      color->setForeground(it1.second);
      color->setBackgroundColor(it2.second);
      int index = x * color_map.size() + y;
      ui->tableWidget->setItem(index, 0, color);
      ui->tableWidget->setItem(
          index, 1, new QTableWidgetItem(QString(it1.first.c_str())));
      ui->tableWidget->setItem(
          index, 2, new QTableWidgetItem(QString(it2.first.c_str())));
      y++;
    }
    x++;
  }
}

MainWindow::~MainWindow() { delete ui; }
